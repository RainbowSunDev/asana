export const refreshAuthenticationUserAuthMethod = async () => {};
