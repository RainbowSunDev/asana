export const scheduleDataProtectionSyncJobs = async () => {};
